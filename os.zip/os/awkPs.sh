ps -axl | awk -f ps.awk 


