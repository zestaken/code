ls -l /home  | awk -f lsHome.awk
